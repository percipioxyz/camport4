@echo off
chcp 65001 >nul
title USB Driver Installation Tool
setlocal enabledelayedexpansion

:: Check for administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting administrator privileges...
    PowerShell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================
echo     Percipio USB3 Vision Driver Installer
echo ========================================
echo.

:: Set current directory path
set "CURRENT_DIR=%~dp0"
echo Current directory: %CURRENT_DIR%
echo.

:: Check if required files exist
if not exist "%CURRENT_DIR%percipio_u3v_device.cer" (
    echo ERROR: Certificate file not found: percipio_u3v_device.cer
    pause
    exit /b 1
)

if not exist "%CURRENT_DIR%PERCIPIO_U3V_DEVICE.inf" (
    echo ERROR: Driver file not found: PERCIPIO_U3V_DEVICE.inf
    pause
    exit /b 1
)

:: Step 1: Install certificate
echo [1/3] Installing digital certificate...
certutil -addstore "Root" "%CURRENT_DIR%percipio_u3v_device.cer"
if %errorLevel% equ 0 (
    echo [✓] Certificate installed successfully
) else (
    echo [✗] Certificate installation failed
    pause
    exit /b 1
)
echo.

:: Step 2: Pre-install driver
echo [2/3] Pre-installing USB driver...
echo Method 1: Using pnputil...
pnputil /add-driver "%CURRENT_DIR%PERCIPIO_U3V_DEVICE.inf" /install

if %errorLevel% neq 0 (
    echo Pnputil failed, trying Method 2...
    echo Method 2: Using INF installation...
    rundll32.exe setupapi,InstallHinfSection DefaultInstall 132 "%CURRENT_DIR%PERCIPIO_U3V_DEVICE.inf"
)

if %errorLevel% equ 0 (
    echo [✓] USB driver pre-installed successfully
    echo.
    echo [3/3] Waiting for device connection...
    echo.
    echo ========================================
    echo         Installation Complete!
    echo ========================================
    echo.
    echo IMPORTANT NOTES:
    echo 1. Please make sure the device is NOT connected to the computer
    echo 2. Wait 30 seconds for system to complete driver registration
    echo 3. Then connect the device to the computer
    echo 4. System will automatically detect and install the driver
    echo.
    echo To scan for hardware changes manually:
    echo Open Device Manager -> Action -> Scan for hardware changes
    echo.
) else (
    echo [✗] USB driver installation failed
    echo.
    echo Please try manual installation:
    echo 1. Right-click on PERCIPIO_U3V_DEVICE.inf file
    echo 2. Select "Install"
    echo 3. Follow the prompts
    echo.
)

:: Add hardware scan option
echo Do you want to scan for hardware changes?
echo This will immediately detect any connected devices.
set /p choice=(Y/N, press N to skip): 
if /i "%choice%"=="Y" (
    echo Scanning for hardware changes...
    devcon rescan 2>nul
    if %errorLevel% neq 0 (
        echo Note: devcon not found, using PowerShell...
        PowerShell -Command "Update-Driver -ScanOnly"
    )
    echo Scan complete!
    echo.
    echo If device is connected, system will start installing driver.
    echo Check Device Manager to verify installation status.
)

echo.
echo Press any key to exit...
pause >nul